import pytest
from flask_stats.APIclient import APIclient

def test_always_passes():
    assert False

def test_total_deposits():
    client = APIclient()
    td = client.total_deposits(freq=None, latest=False)
    assert isinstance(td, int)